#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::Prison" for configuration "None"
set_property(TARGET KF6::Prison APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::Prison PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "ZXing::ZXing"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6Prison.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6Prison.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::Prison )
list(APPEND _cmake_import_check_files_for_KF6::Prison "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6Prison.so.6.13.0" )

# Import target "KF6::PrisonScanner" for configuration "None"
set_property(TARGET KF6::PrisonScanner APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::PrisonScanner PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core;ZXing::ZXing"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6PrisonScanner.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6PrisonScanner.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::PrisonScanner )
list(APPEND _cmake_import_check_files_for_KF6::PrisonScanner "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6PrisonScanner.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
