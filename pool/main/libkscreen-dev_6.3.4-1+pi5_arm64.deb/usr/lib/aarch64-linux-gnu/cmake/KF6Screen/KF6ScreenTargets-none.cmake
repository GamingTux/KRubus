#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::ScreenDpms" for configuration "None"
set_property(TARGET KF6::ScreenDpms APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::ScreenDpms PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::WaylandClient"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6ScreenDpms.so.6.3.4"
  IMPORTED_SONAME_NONE "libKF6ScreenDpms.so.8"
  )

list(APPEND _cmake_import_check_targets KF6::ScreenDpms )
list(APPEND _cmake_import_check_files_for_KF6::ScreenDpms "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6ScreenDpms.so.6.3.4" )

# Import target "KF6::Screen" for configuration "None"
set_property(TARGET KF6::Screen APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::Screen PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::DBus"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6Screen.so.6.3.4"
  IMPORTED_SONAME_NONE "libKF6Screen.so.8"
  )

list(APPEND _cmake_import_check_targets KF6::Screen )
list(APPEND _cmake_import_check_files_for_KF6::Screen "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6Screen.so.6.3.4" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
