#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::UserFeedbackCore" for configuration "None"
set_property(TARGET KF6::UserFeedbackCore APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::UserFeedbackCore PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Gui;Qt6::Network"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6UserFeedbackCore.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6UserFeedbackCore.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::UserFeedbackCore )
list(APPEND _cmake_import_check_files_for_KF6::UserFeedbackCore "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6UserFeedbackCore.so.6.13.0" )

# Import target "KF6::UserFeedbackWidgets" for configuration "None"
set_property(TARGET KF6::UserFeedbackWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::UserFeedbackWidgets PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6UserFeedbackWidgets.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6UserFeedbackWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::UserFeedbackWidgets )
list(APPEND _cmake_import_check_files_for_KF6::UserFeedbackWidgets "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6UserFeedbackWidgets.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
