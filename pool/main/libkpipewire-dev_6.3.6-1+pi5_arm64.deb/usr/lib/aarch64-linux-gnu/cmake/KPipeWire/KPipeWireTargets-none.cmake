#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "K::KPipeWire" for configuration "None"
set_property(TARGET K::KPipeWire APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(K::KPipeWire PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Quick;KF6::I18n;KF6::CoreAddons"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKPipeWire.so.6.3.90"
  IMPORTED_SONAME_NONE "libKPipeWire.so.6"
  )

list(APPEND _cmake_import_check_targets K::KPipeWire )
list(APPEND _cmake_import_check_files_for_K::KPipeWire "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKPipeWire.so.6.3.90" )

# Import target "K::KPipeWireRecord" for configuration "None"
set_property(TARGET K::KPipeWireRecord APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(K::KPipeWireRecord PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core;Qt6::Gui;KF6::CoreAddons;K::KPipeWireDmaBuf"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKPipeWireRecord.so.6.3.90"
  IMPORTED_SONAME_NONE "libKPipeWireRecord.so.6"
  )

list(APPEND _cmake_import_check_targets K::KPipeWireRecord )
list(APPEND _cmake_import_check_files_for_K::KPipeWireRecord "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKPipeWireRecord.so.6.3.90" )

# Import target "K::KPipeWireDmaBuf" for configuration "None"
set_property(TARGET K::KPipeWireDmaBuf APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(K::KPipeWireDmaBuf PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core;Qt6::Gui"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKPipeWireDmaBuf.so.6.3.90"
  IMPORTED_SONAME_NONE "libKPipeWireDmaBuf.so.6"
  )

list(APPEND _cmake_import_check_targets K::KPipeWireDmaBuf )
list(APPEND _cmake_import_check_files_for_K::KPipeWireDmaBuf "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKPipeWireDmaBuf.so.6.3.90" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
