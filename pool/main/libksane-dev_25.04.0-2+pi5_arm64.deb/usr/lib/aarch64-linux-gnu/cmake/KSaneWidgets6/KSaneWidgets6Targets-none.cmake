#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KSaneWidgets6" for configuration "None"
set_property(TARGET KSaneWidgets6 APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSaneWidgets6 PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::Wallet;KF6::I18n;KF6::WidgetsAddons;KF6::TextWidgets;KSane6::Core"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSaneWidgets6.so.25.04.0"
  IMPORTED_SONAME_NONE "libKSaneWidgets6.so.6"
  )

list(APPEND _cmake_import_check_targets KSaneWidgets6 )
list(APPEND _cmake_import_check_files_for_KSaneWidgets6 "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSaneWidgets6.so.25.04.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
