#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::DBusAddons" for configuration "None"
set_property(TARGET KF6::DBusAddons APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::DBusAddons PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6DBusAddons.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6DBusAddons.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::DBusAddons )
list(APPEND _cmake_import_check_files_for_KF6::DBusAddons "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6DBusAddons.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
