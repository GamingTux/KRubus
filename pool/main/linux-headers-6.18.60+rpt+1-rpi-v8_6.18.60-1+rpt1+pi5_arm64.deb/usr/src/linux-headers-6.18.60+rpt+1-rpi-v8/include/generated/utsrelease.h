#define UTS_RELEASE "6.18.60+rpt+1-rpi-v8"
