#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::NewStuffWidgets" for configuration "None"
set_property(TARGET KF6::NewStuffWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::NewStuffWidgets PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::I18n;KF6::ConfigCore;KF6::WidgetsAddons;Qt6::Qml;Qt6::Quick;Qt6::QuickWidgets;KF6::I18nQml"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6NewStuffWidgets.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6NewStuffWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::NewStuffWidgets )
list(APPEND _cmake_import_check_files_for_KF6::NewStuffWidgets "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6NewStuffWidgets.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
