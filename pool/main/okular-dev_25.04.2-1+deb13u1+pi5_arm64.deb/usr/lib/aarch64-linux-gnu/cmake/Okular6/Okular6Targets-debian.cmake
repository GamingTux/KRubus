#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Okular::Core" for configuration "Debian"
set_property(TARGET Okular::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(Okular::Core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_DEBIAN "KF6::Archive;KF6::KIOCore;KF6::KIOWidgets;KF6::I18n;KF6::ThreadWeaver;KF6::BookmarksWidgets;KF6::Bookmarks;Qt6::Svg;Phonon::phonon4qt6;KF6::Wallet;Qt6::Qml"
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libOkular6Core.so.3.0.0"
  IMPORTED_SONAME_DEBIAN "libOkular6Core.so.3"
  )

list(APPEND _cmake_import_check_targets Okular::Core )
list(APPEND _cmake_import_check_files_for_Okular::Core "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libOkular6Core.so.3.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
