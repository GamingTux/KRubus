#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::BundledResonanceAudio" for configuration "None"
set_property(TARGET Qt6::BundledResonanceAudio APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::BundledResonanceAudio PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C;CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQt6BundledResonanceAudio.a"
  )

list(APPEND _cmake_import_check_targets Qt6::BundledResonanceAudio )
list(APPEND _cmake_import_check_files_for_Qt6::BundledResonanceAudio "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQt6BundledResonanceAudio.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
