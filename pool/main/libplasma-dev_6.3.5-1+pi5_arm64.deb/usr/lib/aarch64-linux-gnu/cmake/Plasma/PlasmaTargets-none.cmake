#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::Plasma" for configuration "None"
set_property(TARGET Plasma::Plasma APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Plasma::Plasma PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Quick;Qt6::WaylandClient;KF6::ConfigGui;KF6::ColorScheme;KF6::ConfigQml;KF6::Archive;KF6::GuiAddons;KF6::I18n;KF6::WindowSystem;KF6::GlobalAccel;KF6::Notifications;KF6::IconThemes;Plasma::Activities;KF6::Svg;KF6::Package"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libPlasma.so.6.3.5"
  IMPORTED_SONAME_NONE "libPlasma.so.6"
  )

list(APPEND _cmake_import_check_targets Plasma::Plasma )
list(APPEND _cmake_import_check_files_for_Plasma::Plasma "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libPlasma.so.6.3.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
