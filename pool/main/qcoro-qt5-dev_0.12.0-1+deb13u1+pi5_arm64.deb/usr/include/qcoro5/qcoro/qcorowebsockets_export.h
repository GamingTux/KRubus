
#ifndef QCOROWEBSOCKETS_EXPORT_H
#define QCOROWEBSOCKETS_EXPORT_H

#ifdef QCOROWEBSOCKETS_STATIC_DEFINE
#  define QCOROWEBSOCKETS_EXPORT
#  define QCOROWEBSOCKETS_NO_EXPORT
#else
#  ifndef QCOROWEBSOCKETS_EXPORT
#    ifdef QCoro5WebSockets_EXPORTS
        /* We are building this library */
#      define QCOROWEBSOCKETS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define QCOROWEBSOCKETS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef QCOROWEBSOCKETS_NO_EXPORT
#    define QCOROWEBSOCKETS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef QCOROWEBSOCKETS_DEPRECATED
#  define QCOROWEBSOCKETS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef QCOROWEBSOCKETS_DEPRECATED_EXPORT
#  define QCOROWEBSOCKETS_DEPRECATED_EXPORT QCOROWEBSOCKETS_EXPORT QCOROWEBSOCKETS_DEPRECATED
#endif

#ifndef QCOROWEBSOCKETS_DEPRECATED_NO_EXPORT
#  define QCOROWEBSOCKETS_DEPRECATED_NO_EXPORT QCOROWEBSOCKETS_NO_EXPORT QCOROWEBSOCKETS_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef QCOROWEBSOCKETS_NO_DEPRECATED
#    define QCOROWEBSOCKETS_NO_DEPRECATED
#  endif
#endif

#endif /* QCOROWEBSOCKETS_EXPORT_H */
