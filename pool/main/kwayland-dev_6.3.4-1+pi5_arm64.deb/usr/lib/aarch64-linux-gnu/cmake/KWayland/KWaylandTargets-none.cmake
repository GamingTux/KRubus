#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Plasma::KWaylandClient" for configuration "None"
set_property(TARGET Plasma::KWaylandClient APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Plasma::KWaylandClient PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Concurrent"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKWaylandClient.so.6.3.4"
  IMPORTED_SONAME_NONE "libKWaylandClient.so.6"
  )

list(APPEND _cmake_import_check_targets Plasma::KWaylandClient )
list(APPEND _cmake_import_check_files_for_Plasma::KWaylandClient "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKWaylandClient.so.6.3.4" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
