#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PK::packagekitqt6" for configuration "Debian"
set_property(TARGET PK::packagekitqt6 APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(PK::packagekitqt6 PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpackagekitqt6.so.1.1.2"
  IMPORTED_SONAME_DEBIAN "libpackagekitqt6.so.1"
  )

list(APPEND _cmake_import_check_targets PK::packagekitqt6 )
list(APPEND _cmake_import_check_files_for_PK::packagekitqt6 "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpackagekitqt6.so.1.1.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
