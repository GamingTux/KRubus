#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LayerShellQt::Interface" for configuration "Debian"
set_property(TARGET LayerShellQt::Interface APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(LayerShellQt::Interface PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libLayerShellQtInterface.so.6.3.4"
  IMPORTED_SONAME_DEBIAN "libLayerShellQtInterface.so.6"
  )

list(APPEND _cmake_import_check_targets LayerShellQt::Interface )
list(APPEND _cmake_import_check_files_for_LayerShellQt::Interface "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libLayerShellQtInterface.so.6.3.4" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
