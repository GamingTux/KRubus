#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "kImageAnnotator::kImageAnnotator" for configuration "None"
set_property(TARGET kImageAnnotator::kImageAnnotator APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(kImageAnnotator::kImageAnnotator PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "kColorPicker::kColorPicker"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libkImageAnnotator-Qt5.so.0.7.1"
  IMPORTED_SONAME_NONE "libkImageAnnotator-Qt5.so.0"
  )

list(APPEND _cmake_import_check_targets kImageAnnotator::kImageAnnotator )
list(APPEND _cmake_import_check_files_for_kImageAnnotator::kImageAnnotator "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libkImageAnnotator-Qt5.so.0.7.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
