#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PW::LibNotificationManager" for configuration "None"
set_property(TARGET PW::LibNotificationManager APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(PW::LibNotificationManager PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::DBus;KF6::ConfigGui;KF6::I18n;KF6::WindowSystem;KF6::ItemModels;KF6::Notifications;KF6::KIOFileWidgets;Plasma::Plasma;KF6::Screen;KF6::Service;Qt6::Qml"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libnotificationmanager.so.6.3.6"
  IMPORTED_SONAME_NONE "libnotificationmanager.so.1"
  )

list(APPEND _cmake_import_check_targets PW::LibNotificationManager )
list(APPEND _cmake_import_check_files_for_PW::LibNotificationManager "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libnotificationmanager.so.6.3.6" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
