#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Phonon::phonon4qt5experimental" for configuration "Debian"
set_property(TARGET Phonon::phonon4qt5experimental APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(Phonon::phonon4qt5experimental PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libphonon4qt5experimental.so.4.12.0"
  IMPORTED_SONAME_DEBIAN "libphonon4qt5experimental.so.4"
  )

list(APPEND _cmake_import_check_targets Phonon::phonon4qt5experimental )
list(APPEND _cmake_import_check_files_for_Phonon::phonon4qt5experimental "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libphonon4qt5experimental.so.4.12.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
