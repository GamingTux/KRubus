#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::kauth-policy-gen" for configuration "None"
set_property(TARGET KF6::kauth-policy-gen APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::kauth-policy-gen PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/kf6/kauth/libexec/kauth-policy-gen"
  )

list(APPEND _cmake_import_check_targets KF6::kauth-policy-gen )
list(APPEND _cmake_import_check_files_for_KF6::kauth-policy-gen "${_IMPORT_PREFIX}/lib/kf6/kauth/libexec/kauth-policy-gen" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
