#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF5::KDcraw" for configuration "Debian"
set_property(TARGET KF5::KDcraw APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(KF5::KDcraw PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF5KDcraw.so.5.0.0"
  IMPORTED_SONAME_DEBIAN "libKF5KDcraw.so.5"
  )

list(APPEND _cmake_import_check_targets KF5::KDcraw )
list(APPEND _cmake_import_check_files_for_KF5::KDcraw "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF5KDcraw.so.5.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
