#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KSane6::Core" for configuration "None"
set_property(TARGET KSane6::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSane6::Core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::I18n"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSaneCore6.so.25.04.0"
  IMPORTED_SONAME_NONE "libKSaneCore6.so.1"
  )

list(APPEND _cmake_import_check_targets KSane6::Core )
list(APPEND _cmake_import_check_files_for_KSane6::Core "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSaneCore6.so.25.04.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
