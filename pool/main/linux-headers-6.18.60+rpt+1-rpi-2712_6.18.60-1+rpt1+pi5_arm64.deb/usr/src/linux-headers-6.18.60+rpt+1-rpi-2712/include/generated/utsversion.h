#define UTS_VERSION "#1 SMP PREEMPT Debian 1:6.18.60-1+rpt1+pi5 (2026-11-07)"
