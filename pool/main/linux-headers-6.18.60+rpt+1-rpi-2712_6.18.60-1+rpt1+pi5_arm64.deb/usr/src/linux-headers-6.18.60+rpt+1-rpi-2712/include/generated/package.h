#define LINUX_PACKAGE_ID " Debian 1:6.18.60-1+rpt1+pi5"
