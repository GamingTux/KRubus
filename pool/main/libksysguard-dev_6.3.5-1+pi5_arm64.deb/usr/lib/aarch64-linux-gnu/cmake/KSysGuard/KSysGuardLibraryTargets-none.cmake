#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KSysGuard::Formatter" for configuration "None"
set_property(TARGET KSysGuard::Formatter APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSysGuard::Formatter PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::CoreAddons;KF6::I18n"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardFormatter.so.6.3.5"
  IMPORTED_SONAME_NONE "libKSysGuardFormatter.so.2"
  )

list(APPEND _cmake_import_check_targets KSysGuard::Formatter )
list(APPEND _cmake_import_check_files_for_KSysGuard::Formatter "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardFormatter.so.6.3.5" )

# Import target "KSysGuard::ProcessCore" for configuration "None"
set_property(TARGET KSysGuard::ProcessCore APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSysGuard::ProcessCore PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::I18n;KF6::AuthCore;KF6::CoreAddons;KF6::Service"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libprocesscore.so.6.3.5"
  IMPORTED_SONAME_NONE "libprocesscore.so.10"
  )

list(APPEND _cmake_import_check_targets KSysGuard::ProcessCore )
list(APPEND _cmake_import_check_files_for_KSysGuard::ProcessCore "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libprocesscore.so.6.3.5" )

# Import target "KSysGuard::Sensors" for configuration "None"
set_property(TARGET KSysGuard::Sensors APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSysGuard::Sensors PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core;Qt6::DBus;KF6::I18n;KSysGuard::SystemStats"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardSensors.so.6.3.5"
  IMPORTED_SONAME_NONE "libKSysGuardSensors.so.2"
  )

list(APPEND _cmake_import_check_targets KSysGuard::Sensors )
list(APPEND _cmake_import_check_files_for_KSysGuard::Sensors "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardSensors.so.6.3.5" )

# Import target "KSysGuard::SensorFaces" for configuration "None"
set_property(TARGET KSysGuard::SensorFaces APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSysGuard::SensorFaces PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt6::Core;Qt6::DBus;KF6::I18n;KF6::Package;KF6::ConfigQml;KF6::Solid"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardSensorFaces.so.6.3.5"
  IMPORTED_SONAME_NONE "libKSysGuardSensorFaces.so.2"
  )

list(APPEND _cmake_import_check_targets KSysGuard::SensorFaces )
list(APPEND _cmake_import_check_files_for_KSysGuard::SensorFaces "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardSensorFaces.so.6.3.5" )

# Import target "KSysGuard::SystemStats" for configuration "None"
set_property(TARGET KSysGuard::SystemStats APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KSysGuard::SystemStats PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardSystemStats.so.6.3.5"
  IMPORTED_SONAME_NONE "libKSysGuardSystemStats.so.2"
  )

list(APPEND _cmake_import_check_targets KSysGuard::SystemStats )
list(APPEND _cmake_import_check_files_for_KSysGuard::SystemStats "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKSysGuardSystemStats.so.6.3.5" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
