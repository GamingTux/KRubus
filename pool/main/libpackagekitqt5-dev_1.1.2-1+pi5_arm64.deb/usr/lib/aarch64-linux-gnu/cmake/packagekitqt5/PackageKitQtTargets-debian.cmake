#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PK::packagekitqt5" for configuration "Debian"
set_property(TARGET PK::packagekitqt5 APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(PK::packagekitqt5 PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpackagekitqt5.so.1.1.2"
  IMPORTED_SONAME_DEBIAN "libpackagekitqt5.so.1"
  )

list(APPEND _cmake_import_check_targets PK::packagekitqt5 )
list(APPEND _cmake_import_check_files_for_PK::packagekitqt5 "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libpackagekitqt5.so.1.1.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
