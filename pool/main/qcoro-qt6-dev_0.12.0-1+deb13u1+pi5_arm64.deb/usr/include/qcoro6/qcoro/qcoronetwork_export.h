
#ifndef QCORONETWORK_EXPORT_H
#define QCORONETWORK_EXPORT_H

#ifdef QCORONETWORK_STATIC_DEFINE
#  define QCORONETWORK_EXPORT
#  define QCORONETWORK_NO_EXPORT
#else
#  ifndef QCORONETWORK_EXPORT
#    ifdef QCoro6Network_EXPORTS
        /* We are building this library */
#      define QCORONETWORK_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define QCORONETWORK_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef QCORONETWORK_NO_EXPORT
#    define QCORONETWORK_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef QCORONETWORK_DEPRECATED
#  define QCORONETWORK_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef QCORONETWORK_DEPRECATED_EXPORT
#  define QCORONETWORK_DEPRECATED_EXPORT QCORONETWORK_EXPORT QCORONETWORK_DEPRECATED
#endif

#ifndef QCORONETWORK_DEPRECATED_NO_EXPORT
#  define QCORONETWORK_DEPRECATED_NO_EXPORT QCORONETWORK_NO_EXPORT QCORONETWORK_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef QCORONETWORK_NO_DEPRECATED
#    define QCORONETWORK_NO_DEPRECATED
#  endif
#endif

#endif /* QCORONETWORK_EXPORT_H */
