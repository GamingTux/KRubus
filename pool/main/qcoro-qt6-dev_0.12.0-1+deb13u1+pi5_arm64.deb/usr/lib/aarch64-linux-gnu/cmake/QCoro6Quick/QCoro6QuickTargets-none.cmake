#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QCoro6::Quick" for configuration "None"
set_property(TARGET QCoro6::Quick APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(QCoro6::Quick PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQCoro6Quick.so.0.12.0"
  IMPORTED_SONAME_NONE "libQCoro6Quick.so.0"
  )

list(APPEND _cmake_import_check_targets QCoro6::Quick )
list(APPEND _cmake_import_check_files_for_QCoro6::Quick "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQCoro6Quick.so.0.12.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
