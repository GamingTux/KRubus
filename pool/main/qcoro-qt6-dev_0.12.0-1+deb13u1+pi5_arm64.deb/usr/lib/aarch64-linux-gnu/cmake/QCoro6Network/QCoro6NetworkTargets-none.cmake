#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QCoro6::Network" for configuration "None"
set_property(TARGET QCoro6::Network APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(QCoro6::Network PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQCoro6Network.so.0.12.0"
  IMPORTED_SONAME_NONE "libQCoro6Network.so.0"
  )

list(APPEND _cmake_import_check_targets QCoro6::Network )
list(APPEND _cmake_import_check_files_for_QCoro6::Network "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libQCoro6Network.so.0.12.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
