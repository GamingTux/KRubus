#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KirigamiAddonsStatefulApp" for configuration "Debian"
set_property(TARGET KirigamiAddonsStatefulApp APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(KirigamiAddonsStatefulApp PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_DEBIAN "KF6::I18n;KF6::CoreAddons"
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiAddonsStatefulApp.so.1.7.0"
  IMPORTED_SONAME_DEBIAN "libKirigamiAddonsStatefulApp.so.6"
  )

list(APPEND _cmake_import_check_targets KirigamiAddonsStatefulApp )
list(APPEND _cmake_import_check_files_for_KirigamiAddonsStatefulApp "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKirigamiAddonsStatefulApp.so.1.7.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
