#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KDcrawQt6" for configuration "Debian"
set_property(TARGET KDcrawQt6 APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(KDcrawQt6 PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKDcrawQt6.so.5.0.0"
  IMPORTED_SONAME_DEBIAN "libKDcrawQt6.so.5"
  )

list(APPEND _cmake_import_check_targets KDcrawQt6 )
list(APPEND _cmake_import_check_files_for_KDcrawQt6 "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKDcrawQt6.so.5.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
