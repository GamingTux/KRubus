#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KF6::ConfigWidgets" for configuration "None"
set_property(TARGET KF6::ConfigWidgets APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(KF6::ConfigWidgets PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "KF6::CoreAddons;KF6::GuiAddons;KF6::I18n;KF6::Codecs;Qt6::DBus"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6ConfigWidgets.so.6.13.0"
  IMPORTED_SONAME_NONE "libKF6ConfigWidgets.so.6"
  )

list(APPEND _cmake_import_check_targets KF6::ConfigWidgets )
list(APPEND _cmake_import_check_files_for_KF6::ConfigWidgets "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libKF6ConfigWidgets.so.6.13.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
