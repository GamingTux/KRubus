#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debian".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "FutureSQL6::FutureSQL" for configuration "Debian"
set_property(TARGET FutureSQL6::FutureSQL APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBIAN)
set_target_properties(FutureSQL6::FutureSQL PROPERTIES
  IMPORTED_LOCATION_DEBIAN "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libfuturesql6.so.0"
  IMPORTED_SONAME_DEBIAN "libfuturesql6.so.0"
  )

list(APPEND _cmake_import_check_targets FutureSQL6::FutureSQL )
list(APPEND _cmake_import_check_files_for_FutureSQL6::FutureSQL "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libfuturesql6.so.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
